## My Thoughts on Functional Programming
* Removes state from the equation
* Improves code flexibility
* Removes some code cruft
* Gets confusing in its ceremony
* Definitely some things we can use here
