# Any Questions?

> Presented By: [Amos Garner](https://github.com/AmosGarner)
> @[BitFiendCoder](https://twitter.com/BitFiendCoder)

My Other Talks: [Github.com/AmosGarner/Developer_Presentations](https://github.com/AmosGarner/Developer_Presentations)
