## Common Problems W/ Functional Solutions
