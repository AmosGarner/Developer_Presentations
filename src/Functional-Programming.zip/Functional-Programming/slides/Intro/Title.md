# Git Functional

A memory dump of Lambda Squared and some words on Functional Programming.

### Presenter: [Amos Garner](https://github.com/AmosGarner)
