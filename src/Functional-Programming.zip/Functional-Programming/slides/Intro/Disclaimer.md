## Disclaimer:
> I went to one conference and did some googeling.
> This does not make me an expert.

> Opinionated... sure, but not an expert.
> So be sure to take this talk with a whole cup of salt.
