## Backstory
>In the beginning there was suffering. Then there was Haskell, and the suffering continued.

>Do not try to change the state; that's impossible. Instead only try to realize the truth: There is no state.
